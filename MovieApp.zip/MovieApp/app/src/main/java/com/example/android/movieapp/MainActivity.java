package com.example.android.movieapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //class variables
    Context context;
    GridView gridViewMoviesPosters;
    ImageView imageViewPoster;
    ArrayList<Movies> movieslist = new ArrayList<Movies>();
    customAdapter adapter;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(getApplicationContext());

        gridViewMoviesPosters = (GridView) findViewById(R.id.gv_moviesPosters);
        imageViewPoster = (ImageView) findViewById(R.id.iv_poster);

        //set data of movies list in the adapter
        adapter = new customAdapter(getApplicationContext(), movieslist);
        gridViewMoviesPosters.setAdapter(adapter);
        new MoviesDataTask().execute("popular");

        //show the details of clicked movie in the detailActivity
        gridViewMoviesPosters.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Movies movie = (Movies) parent.getAdapter().getItem(position);
                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
                intent.putExtra("id", movie.getId());
                intent.putExtra("overview", movie.getOverview().toString());
                intent.putExtra("poster", movie.getPoster().toString());
                intent.putExtra("originalTitle", movie.getOriginal_title().toString());
                intent.putExtra("voteAverage", movie.getVoteAverage().toString());
                intent.putExtra("releaseDate", movie.getReleaseDate().toString());
                intent.putExtra("voteCount", movie.getVoteCount().toString());

                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_most_Popular) {
            new MoviesDataTask().execute("popular");
            movieslist.clear();
            return true;
        }
        if (id == R.id.action_high_rated) {
            new MoviesDataTask().execute("top_rated");
            movieslist.clear();
            return true;
        }
        if (id == R.id.action_favourite) {
            adapter.setData(databaseHelper.select_favourites());
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //adapter class
    public class customAdapter extends BaseAdapter {

        ArrayList<Movies> movieslist = new ArrayList<>();

        public customAdapter(Context applicationContext, ArrayList<Movies> Movies) {
            context = applicationContext;
            this.movieslist.addAll(Movies);
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return movieslist.size();
        }

        @Override
        public Object getItem(int position) {
            return movieslist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return movieslist.get(position).id;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view = getLayoutInflater().inflate(R.layout.img, parent, false);
            imageViewPoster = (ImageView) view.findViewById(R.id.iv_poster);
            Picasso.with(getApplicationContext())
                    .load("http://image.tmdb.org/t/p/w342" + movieslist.get(position).poster).into(imageViewPoster);
            return view;
        }

        public void setData(ArrayList<Movies> movies) {
            movieslist.clear();
            movieslist.addAll(movies);
            notifyDataSetChanged();
        }
    }

//{"original_title":"Fight Club","overview":"A ticking-time-bomb insomniac","release_date":"1999-10-14","vote_average":8.1,"vote_count":5129}

    //AsyncTask class
    public class MoviesDataTask extends AsyncTask<String, Void, ArrayList<Movies>> {

        @Override
        protected ArrayList<Movies> doInBackground(String... params) {
            //https://api.themoviedb.org/3/movie/550?api_key=e7a4b07cb72a8637e321815d9aa70234
            //http://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=e7a4b07cb72a8637e321815d9aa70234
            if (params.length == 0) {
                return null;
            }
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String MovieJsonStr = null;       // Will contain the raw JSON response as a string.
            String appId = "e7a4b07cb72a8637e321815d9aa70234";
            try {
                final String MOVIE_BASE_URL = "https://api.themoviedb.org/3/movie/";
                final String API_KEY_PARAM = "api_key";

                Uri builtUri = Uri.parse(MOVIE_BASE_URL).buildUpon()
                        .appendPath(params[0])
                        .appendQueryParameter(API_KEY_PARAM, appId).build();

                URL url = new URL(builtUri.toString());

                // Create the request to theMovieDB, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;  //MovieJsonStr = null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {     // Stream was empty.  No point in parsing, MovieJsonStr = null;
                    return null;
                }

                MovieJsonStr = buffer.toString();

            } catch (IOException e) {                // If the code didn't successfully get the movie data,
                MovieJsonStr = null;                 // there's no point in attempting to parse it.
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            try {
                return getMoviesDataFromJson(MovieJsonStr);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        private ArrayList<Movies> getMoviesDataFromJson(String MoviesJsonString)
                throws JSONException {

            // These are the names of the JSON objects that need to be extracted.
            final String m_id = "id";
            final String m_overview = "overview";
            final String m_poster = "poster_path";
            final String m_original_title = "original_title";
            final String m_vote_average = "vote_average";
            final String m_release_date = "release_date";
            final String m_vote_count = "vote_count";

            JSONObject moviesJsonList = new JSONObject(MoviesJsonString);
            JSONArray movieJsonArray = moviesJsonList.getJSONArray("results");

            for (int i = 0; i < movieJsonArray.length(); i++) {

                int id;
                String overview;
                String poster;
                String original_title;
                String voteAverage;
                String releaseDate;
                String vote_count;

                JSONObject movieJson = (JSONObject) movieJsonArray.get(i);

                id = Integer.parseInt(movieJson.getString(m_id));
                overview = movieJson.getString(m_overview);
                poster = movieJson.getString(m_poster);
                original_title = movieJson.getString(m_original_title);
                voteAverage = movieJson.getString(m_vote_average);
                releaseDate = movieJson.getString(m_release_date);
                vote_count = movieJson.getString(m_vote_count);

                movieslist.add(new Movies(id, overview, poster, original_title, voteAverage, releaseDate, vote_count));
            }
            return movieslist;
        }

        @Override
        protected void onPostExecute(ArrayList<Movies> result) {
            super.onPostExecute(result);
            adapter.setData(result);
        }
    }

}
