package com.example.android.movieapp;

/**
 * Created by FAI on 27/08/2016.
 */
public class Movies {

    int id;
    String overview;
    String poster;
    String original_title;
    String voteAverage;
    String releaseDate;
    String voteCount;

    public Movies() {

    }

    public Movies(int id, String overview, String poster, String original_title, String vote_average, String release_date, String voteCount) {
        this.id = id;
        this.overview = overview;
        this.poster = poster;
        this.original_title = original_title;
        this.voteAverage = vote_average;
        this.releaseDate = release_date;
        this.voteCount = voteCount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getOriginal_title() {
        return original_title;
    }

    public void setOriginal_title(String original_title) {
        this.original_title = original_title;
    }

    public String getVoteAverage() {
        return voteAverage;
    }

    public void setVoteAverage(String voteAverage) {
        this.voteAverage = voteAverage;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getVoteCount() {
        return voteCount;
    }

    public void setVoteCount(String voteCount) {
        this.voteCount = voteCount;
    }

}
