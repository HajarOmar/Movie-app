package com.example.android.movieapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by FAI on 9/16/2016.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;

    private static final String DATABASE_NAME = "fav_data";
    private static final String TABLE_NAME = "Favourite";

    private static final String COL_ID = "id";
    private static final String COL_OVERVIEW = "overview";
    private static final String COL_POSTER = "poster";
    private static final String COL_ORIGINAL_TITLE = "original_title";
    private static final String COL_VOTE_AVERAGE = "vote_average";
    private static final String COL_RELEASE_DATE = "release_date";
    private static final String COL_VOTE_COUNT = "voteCount";


    private static final String CREATE_TABLE_MOVIE = "CREATE TABLE "
            + TABLE_NAME + "(" + COL_ID + " INTEGER PRIMARY KEY, " + COL_OVERVIEW
            + " TEXT, " + COL_POSTER + " TEXT, " + COL_ORIGINAL_TITLE
            + " TEXT," + COL_VOTE_AVERAGE + " TEXT, " + COL_RELEASE_DATE + " TEXT, "
            + COL_VOTE_COUNT + " TEXT " + ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_MOVIE);
        } catch (Exception e) {
            System.out.println("Database Exc");
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public long insert_favourite(Movies movie) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_ID, movie.getId());
        values.put(COL_OVERVIEW, movie.getOverview());
        values.put(COL_POSTER, movie.getPoster());
        values.put(COL_ORIGINAL_TITLE, movie.getOriginal_title());
        values.put(COL_VOTE_AVERAGE, movie.getVoteAverage());
        values.put(COL_RELEASE_DATE, movie.getReleaseDate());
        values.put(COL_VOTE_COUNT, movie.getVoteCount());

        // insert row
        long id = db.insert(TABLE_NAME, null, values);
        db.close();

        return id;
    }

    public ArrayList<Movies> select_favourites() {

        ArrayList<Movies> tags = new ArrayList<Movies>();
        String selectQuery = "SELECT  * FROM " + TABLE_NAME + " ;";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Movies t_movie = new Movies();
                t_movie.setId(cursor.getInt((cursor.getColumnIndex(COL_ID))));
                t_movie.setOverview(cursor.getString(cursor.getColumnIndex(COL_OVERVIEW)));
                t_movie.setPoster(cursor.getString((cursor.getColumnIndex(COL_POSTER))));
                t_movie.setOriginal_title(cursor.getString((cursor.getColumnIndex(COL_ORIGINAL_TITLE))));
                t_movie.setVoteAverage(cursor.getString((cursor.getColumnIndex(COL_VOTE_AVERAGE))));
                t_movie.setReleaseDate(cursor.getString((cursor.getColumnIndex(COL_RELEASE_DATE))));
                t_movie.setVoteCount(cursor.getString((cursor.getColumnIndex(COL_VOTE_COUNT))));

                //  adding to tags list
                tags.add(t_movie);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return tags;
    }
}
