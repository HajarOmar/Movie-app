package com.example.android.movieapp;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {

    int m_Id;
    String id, overview, poster, original_title, vote_average, release_date, voteCount;

    DatabaseHelper databaseHelper;
    ArrayList<TextView> TextViewsList;
    ArrayList<Button> ButtonsList;

    ArrayList<String> TrailerList = new ArrayList<String>();
    ArrayList<String> ReviewList = new ArrayList<String>();

    ImageView imageViewPoster;
    TextView textViewOverview, textViewTitle, textViewVoteAverage, textViewReleaseDate, textViewVoteCount;
    LinearLayout linearLayoutTrailers, linearLayoutReviews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        databaseHelper = new DatabaseHelper(getApplicationContext());

        textViewOverview = (TextView) findViewById(R.id.overview_text_view);
        imageViewPoster = (ImageView) findViewById(R.id.poster_image_view);
        textViewTitle = (TextView) findViewById(R.id.title_text_view);
        textViewVoteAverage = (TextView) findViewById(R.id.vote_text_view);
        textViewReleaseDate = (TextView) findViewById(R.id.date_text_view);
        textViewVoteCount = (TextView) findViewById(R.id.voteCount_text_view);

        //Intent intent = this.getIntent();
        //intent.getStringExtra("originalTitle")
        Bundle bundle = getIntent().getExtras();
        id = "" + bundle.getInt("id");
        m_Id = bundle.getInt("id");
        overview = bundle.getString("overview");
        textViewOverview.setText(overview);
        poster = "http://image.tmdb.org/t/p/w500" + bundle.getString("poster");
        Picasso.with(getApplicationContext())
                .load(poster).into(imageViewPoster);
        original_title = bundle.getString("originalTitle");
        textViewTitle.setText(original_title);
        vote_average = bundle.getString("voteAverage");
        textViewVoteAverage.setText(vote_average + "/10");
        release_date = bundle.getString("releaseDate");
        textViewReleaseDate.setText(release_date);
        voteCount = bundle.getString("voteCount");
        textViewVoteCount.setText(vote_average + " vote.");


        //urlVideos = "http://api.themoviedb.org/3/movie/" + id + "/videos?api_key=e7a4b07cb72a8637e321815d9aa70234";
        //urlReviews = "http://api.themoviedb.org/3/movie/" + id + "/reviews?api_key=e7a4b07cb72a8637e321815d9aa70234";

        new TrailersTask().execute(id);
        new ReviewsTask().execute(id);
    }


    //onClick method for make as favourite button
    public void make_favourite(View view) {
        databaseHelper.insert_favourite(new Movies(m_Id, overview, poster, original_title, vote_average, release_date, voteCount));
        Toast.makeText(getApplicationContext(), "Your movie favourite was added!", Toast.LENGTH_LONG).show();
    }

    //onClick method for Trailers button
    public void show_trailers(View view) {

        linearLayoutTrailers = (LinearLayout) findViewById(R.id.layout_linear);
        if (TrailerList.size() == 0) {
            Toast.makeText(getApplicationContext(), "There is no Trailers.", Toast.LENGTH_LONG).show();
        }
        ButtonsList = new ArrayList<>();
        for (int j = 0; j < TrailerList.size(); j++) {

            final Button rowButton = new Button(getApplicationContext());
            ButtonsList.add(rowButton);
            rowButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.trailer, 0, 0, 0);
            //rowButton.setText(R.string.trailer_string + j );
            rowButton.setTextColor(Color.BLUE);
            rowButton.setTextSize(18);
            rowButton.setBackgroundColor(-1);
            rowButton.setTag("tag" + j);

            rowButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String link = (String) rowButton.getTag();
                    for (int i = 0; i < TrailerList.size(); i++) {
                        String l = "tag" + i;
                        if (link.equals(l)) {
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + TrailerList.get(i)));
                            startActivity(browserIntent);
                        }
                    }
                }
            });
            linearLayoutTrailers.addView(rowButton, 5);
        }
    }

    //onClick method for Reviews button
    public void show_reviews(View view) {

        linearLayoutReviews = (LinearLayout) findViewById(R.id.layout_linear);
        if (ReviewList.size() == 0) {
            Toast.makeText(getApplicationContext(), "There is no reviews!", Toast.LENGTH_LONG).show();
        }
        TextViewsList = new ArrayList<>();
        for (int i = 0; i < ReviewList.size(); i++) {

            TextView rowTextView = new TextView(getApplicationContext());
            TextViewsList.add(rowTextView);
            if (i % 2 == 0) {
                rowTextView.setTextColor(Color.DKGRAY);
                rowTextView.setTextSize(20);
                rowTextView.setText(ReviewList.get(i) + " : ");
            } else {
                rowTextView.setText(ReviewList.get(i));
            }
            linearLayoutReviews.addView(rowTextView);
        }
    }


    //Trailers AsyncTask class
    public class TrailersTask extends AsyncTask<String, Void, ArrayList<String>> {

        @Override
        protected ArrayList<String> doInBackground(String... params) {

            if (params.length == 0) {
                return null;
            }
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String MovieJsonStr = null;       // Will contain the raw JSON response as a string.
            String appId = "e7a4b07cb72a8637e321815d9aa70234";
            try {//urlVideos = "http://api.themoviedb.org/3/movie/" + id + "/videos?api_key=e7a4b07cb72a8637e321815d9aa70234";
                final String MOVIE_BASE_URL = "http://api.themoviedb.org/3/movie/";
                final String API_KEY_PARAM = "api_key";

                Uri builtUri = Uri.parse(MOVIE_BASE_URL).buildUpon()
                        .appendPath(params[0]).appendPath("videos")
                        .appendQueryParameter(API_KEY_PARAM, appId).build();

                URL url = new URL(builtUri.toString());
                // Create the request to theMovieDB, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;  //MovieJsonStr = null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {     // Stream was empty.  No point in parsing, MovieJsonStr = null;
                    return null;
                }

                MovieJsonStr = buffer.toString();

            } catch (IOException e) {                // If the code didn't successfully get the movie data,
                MovieJsonStr = null;                 // there's no point in attempting to parse it.
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            try {
                return getTrailersDataFromJson(MovieJsonStr);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        private ArrayList<String> getTrailersDataFromJson(String MoviesJsonString)
                throws JSONException {

            // These are the names of the JSON objects that need to be extracted.
            final String t_key = "key";
            String key;

            JSONObject moviesJsonList = new JSONObject(MoviesJsonString);
            JSONArray movieJsonArray = moviesJsonList.getJSONArray("results");

            for (int i = 0; i < movieJsonArray.length(); i++) {

                JSONObject movieJson = (JSONObject) movieJsonArray.get(i);
                key = movieJson.getString(t_key);
                TrailerList.add(key);
            }
            return TrailerList;
        }

        @Override
        protected void onPostExecute(ArrayList<String> result) {
            super.onPostExecute(result);
        }
    }

    //Trailers AsyncTask class
    public class ReviewsTask extends AsyncTask<String, Void, ArrayList<String>> {

        @Override
        protected ArrayList<String> doInBackground(String... params) {

            if (params.length == 0) {
                return null;
            }
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String MovieJsonStr = null;       // Will contain the raw JSON response as a string.
            String appId = "e7a4b07cb72a8637e321815d9aa70234";
            try {//urlReviews = "http://api.themoviedb.org/3/movie/" + id + "/reviews?api_key=e7a4b07cb72a8637e321815d9aa70234";
                final String MOVIE_BASE_URL = "http://api.themoviedb.org/3/movie/";
                final String API_KEY_PARAM = "api_key";

                Uri builtUri = Uri.parse(MOVIE_BASE_URL).buildUpon()
                        .appendPath(params[0]).appendPath("reviews")
                        .appendQueryParameter(API_KEY_PARAM, appId).build();

                URL url = new URL(builtUri.toString());
                // Create the request to theMovieDB, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;  //MovieJsonStr = null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {     // Stream was empty.  No point in parsing, MovieJsonStr = null;
                    return null;
                }

                MovieJsonStr = buffer.toString();

            } catch (IOException e) {                // If the code didn't successfully get the movie data,
                MovieJsonStr = null;                 // there's no point in attempting to parse it.
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            try {
                return getReviewsDataFromJson(MovieJsonStr);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        private ArrayList<String> getReviewsDataFromJson(String MoviesJsonString)
                throws JSONException {

            // These are the names of the JSON objects that need to be extracted.
            final String t_content = "content";
            String content;

            JSONObject moviesJsonList = new JSONObject(MoviesJsonString);
            JSONArray movieJsonArray = moviesJsonList.getJSONArray("results");

            for (int i = 0; i < movieJsonArray.length(); i++) {

                JSONObject movieJson = (JSONObject) movieJsonArray.get(i);
                content = movieJson.getString(t_content);
                ReviewList.add(content);
            }
            return ReviewList;
        }

        @Override
        protected void onPostExecute(ArrayList<String> result) {
            super.onPostExecute(result);
        }
    }

}
